"""
This file contains number of steps for implementation.

Be careful:
    - If you want to use "\\" into step body, you should write "\\\". This bug will be fixed in the next major release.
"""

tf_impl_step_template = '''
    List of EDA tool commands.
'''