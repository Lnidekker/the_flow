"""
This file contains number of steps for ATPG.

Be careful:
    - If you want to use "\\" into step body, you should write "\\\". This bug will be fixed in the next major release.
"""

tf_atpg_step_template = '''
    List of EDA tool commands.
'''