"""
This file contains number of steps for power analysis.

Be careful:
    - If you want to use "\\" into step body, you should write "\\\". This bug will be fixed in the next major release.
"""

tf_power_step_template = '''
    List of EDA tool commands.
'''